package com.sanj.roomdb.room;

import android.app.Application;
import android.content.Context;

import androidx.annotation.NonNull;
import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;

@Database(entities = {User.class},version = 1,exportSchema = false)
abstract class AppDatabase extends RoomDatabase {
    public abstract UserDAO userDAO();

    private static AppDatabase instance;

    public static AppDatabase getInstance(@NonNull Application application){
        if (instance==null){
            synchronized (AppDatabase.class){
                instance= Room.databaseBuilder(application,AppDatabase.class,"app_db")
                        .fallbackToDestructiveMigration()
                        .build();
            }
        }
        return instance;
    }
}
