package com.sanj.roomdb.room;

import android.os.AsyncTask;

public class DBThreads {
    static class InsertInBackground extends AsyncTask<User,Void,Boolean> {
        private final UserDAO userDAO;

        public InsertInBackground(UserDAO userDAO) {
            this.userDAO = userDAO;
        }


        @Override
        protected Boolean doInBackground(User... users) {
            userDAO.insert(users[0]);
            return true;
        }
    }

    static class DeleteInBackground extends AsyncTask<User,Void,Boolean> {
        private final UserDAO userDAO;

        public DeleteInBackground(UserDAO userDAO) {
            this.userDAO = userDAO;
        }


        @Override
        protected Boolean doInBackground(User... users) {
            userDAO.delete(users[0]);
            return true;
        }
    }

    static class UpdateInBackground extends AsyncTask<User,Void,Boolean> {
        private final UserDAO userDAO;

        public UpdateInBackground(UserDAO userDAO) {
            this.userDAO = userDAO;
        }


        @Override
        protected Boolean doInBackground(User... users) {
            userDAO.update(users[0]);
            return true;
        }
    }
}
