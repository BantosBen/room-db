package com.sanj.roomdb;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.sanj.roomdb.adapter.RecyclerViewAdapter;
import com.sanj.roomdb.room.User;
import com.sanj.roomdb.room.UserViewModel;

import java.util.List;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    private EditText edName;
    private EditText edPassword;
    private RecyclerView recyclerViewData;

    private UserViewModel userViewModel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button btnSave = findViewById(R.id.btn_save);
        edName =findViewById(R.id.ed_name);
        edPassword=findViewById(R.id.ed_password);
        recyclerViewData=findViewById(R.id.recyclerview_data);

        userViewModel=new UserViewModel(getApplication());

        btnSave.setOnClickListener(this);

    }

    @Override
    protected void onStart() {
        super.onStart();
        userViewModel.getUserList().observe(this, this::adapter);
    }

    private void adapter(List<User> users) {
        recyclerViewData.setHasFixedSize(true);
        LinearLayoutManager linearLayoutManager=new LinearLayoutManager(this,LinearLayoutManager.VERTICAL,false);
        recyclerViewData.setLayoutManager(linearLayoutManager);
        recyclerViewData.setAdapter(new RecyclerViewAdapter(users,this,userViewModel));
    }

    @SuppressLint("NonConstantResourceId")
    @Override
    public void onClick(View v) {
        if (v.getId() == R.id.btn_save) {
            addUser();
        }
    }

    private void addUser() {
        String name=edName.getText().toString().trim();
        String password=edPassword.getText().toString().trim();

        edPassword.setText("");
        edName.setText("");

        if(!(TextUtils.isEmpty(name)|| TextUtils.isEmpty(password))){
            userViewModel.insert(new User(0, name,password));
            Toast.makeText(this,"NEW USER ADDED",Toast.LENGTH_LONG).show();
        }else{
            edName.setError("Required");
            edPassword.setError("Required");
        }
    }
}