package com.sanj.roomdb.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.recyclerview.widget.RecyclerView;

import com.sanj.roomdb.R;
import com.sanj.roomdb.room.User;
import com.sanj.roomdb.room.UserViewModel;

import java.util.List;

public class RecyclerViewAdapter extends RecyclerView.Adapter<RecyclerViewAdapter.ViewHolder>{
    private final List<User> mUserList;
    private final Context mContext;
    private final UserViewModel userViewModel;

    public RecyclerViewAdapter(List<User> mUserList, Context mContext,UserViewModel userViewModel) {
        this.mUserList = mUserList;
        this.mContext = mContext;
        this.userViewModel=userViewModel;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view= LayoutInflater.from(parent.getContext()).inflate(R.layout.recycler_view_item,parent,false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        User mUser=mUserList.get(position);
        holder.txtName.setText(mUser.getName());
        holder.btnDelete.setOnClickListener(v -> {
            userViewModel.delete(mUser);
            Toast.makeText(mContext,mUser.getName()+" Deleted",Toast.LENGTH_LONG).show();
        });

        holder.btnEdit.setOnClickListener(v -> {
            EditText edName=new EditText(mContext);
            edName.setText(mUser.getName());
            AlertDialog alertDialogName;
            AlertDialog.Builder builderName =new AlertDialog.Builder(mContext);
            builderName.setTitle("UPDATE");
            builderName.setView(edName);
            builderName.setCancelable(false);
            builderName.setPositiveButton("PROCEED", (dialogName, whichName) -> {
                EditText edPassword=new EditText(mContext);
                edPassword.setText(mUser.getPassword());
                AlertDialog alertDialogPassword;
                AlertDialog.Builder builderPassword=new AlertDialog.Builder(mContext);
                builderPassword.setTitle("UPDATE");
                builderPassword.setView(edPassword);
                builderPassword.setCancelable(false);
                builderPassword.setPositiveButton("UPDATE", (dialogPassword, whichPassword) -> {
                    String name=edName.getText().toString();
                    String password=edPassword.getText().toString();
                    mUser.setName(name);
                    mUser.setPassword(password);
                    userViewModel.update(mUser);
                    Toast.makeText(mContext, "USER UPDATED", Toast.LENGTH_SHORT).show();
                });
                builderPassword.setNegativeButton("CANCEL", (dialogPassword, whichPassword)-> {

                });
                alertDialogPassword= builderName.create();
                alertDialogPassword.show();
            });
            builderName.setNeutralButton("UPDATE NAME", (dialogName, whichName) -> {
                String name=edName.getText().toString();
                mUser.setName(name);
                userViewModel.update(mUser);
                Toast.makeText(mContext, "USER UPDATED", Toast.LENGTH_SHORT).show();
            });
            builderName.setNegativeButton("CANCEL", (dialogName, whichName) -> {

            });
            alertDialogName = builderName.create();
            alertDialogName.show();

        });

    }

    @Override
    public int getItemCount() {
        return mUserList.size();
    }


    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView txtName;
        ImageButton btnEdit;
        ImageButton btnDelete;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            txtName=itemView.findViewById(R.id.txt_name);
            btnDelete=itemView.findViewById(R.id.btn_delete);
            btnEdit=itemView.findViewById(R.id.btn_edit);
        }
    }
}
