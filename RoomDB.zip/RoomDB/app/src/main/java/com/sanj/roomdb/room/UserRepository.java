package com.sanj.roomdb.room;

import android.annotation.SuppressLint;
import android.app.Application;
import android.content.Context;
import android.os.AsyncTask;

import androidx.annotation.NonNull;
import androidx.lifecycle.LiveData;

import java.util.List;

public class UserRepository {

    private final UserDAO mUserDAO;
    private final LiveData<List<User>> mUserList;

    public UserRepository(@NonNull Application application) {
        AppDatabase appDatabase=AppDatabase.getInstance(application);
        mUserDAO=appDatabase.userDAO();
        mUserList=mUserDAO.getAllUsers();
    }

    public LiveData<List<User>> getUserList() {
        return mUserList;
    }

    public void insert(User user){
        new DBThreads.InsertInBackground(mUserDAO).execute(user);
    }
    public void delete(User user){
        new DBThreads.DeleteInBackground(mUserDAO).execute(user);
    }
    public void update(User user){
        new DBThreads.UpdateInBackground(mUserDAO).execute(user);
    }

}
